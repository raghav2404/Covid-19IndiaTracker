package android.example.covid_19indiatracker

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.google.gson.Gson
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.coroutines.*
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

@InternalCoroutinesApi
class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        fetchResults()
    }

    private fun fetchResults() {
        GlobalScope.launch {
            val response = withContext(Dispatchers.IO) { Client.api.clone().execute() }
            if(response.isSuccessful)
            {
              val data=Gson().fromJson(response.body?.string(),Response::class.java)
              launch(Dispatchers.Main) { bindCombinedData(data.statewise[0]) }
            }
        }
    }

    private fun bindCombinedData(data: StatewiseItem) {
        val lastUpdatedTime= data.lastupdatedtime
        val simpleDateFormat=SimpleDateFormat("dd/MM/yyyy HH:mm:ss")
        lastUpdatedTv.text = "Last Updated\n ${getTimeAgo(simpleDateFormat.parse(lastUpdatedTime))}"

    }

     fun getTimeAgo(past:Date):String
    {
    val now=Date()
        val seconds:Long= TimeUnit.MILLISECONDS.toSeconds(now.time-past.time)
        val minutes:Long=TimeUnit.MILLISECONDS.toMinutes(now.time-past.time)
        val hours:Long=TimeUnit.MILLISECONDS.toHours(now.time-past.time)
        return  when
        {
            seconds<60 ->{"Few Seconds ago"}
            minutes<60 ->{"$minutes minutes ago"}
           hours<24 ->{"$hours hours ${minutes%60} min ago"}
            else ->{ SimpleDateFormat("dd/MM/yy, hh:mm a").format(past).toString()}

        }

    }
}
